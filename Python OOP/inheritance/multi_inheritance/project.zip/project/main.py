from teacher import Teacher

t = Teacher()

print(t.sleep())
print(t.get_fired())
print(t.teach())